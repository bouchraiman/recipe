<?php
include 'db_connect.php';

$sql = "SELECT Recipes.recipe_id, Recipes.title, Recipes.description, Recipes.image_url, Users.username FROM Recipes JOIN Users ON Recipes.user_id = Users.user_id";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Recipe Sharing Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes.php">Recipes</a></li>
                <li><a href="submit.php">Submit Recipe</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Welcome to the Recipe Sharing Website</h1>
            <p>Discover, share, and save your favorite recipes!</p>
            <form action="recipes.html" method="get">
                <input type="text" name="search" placeholder="Search for recipes...">
                <button type="submit">Search</button>
            </form>
        </section>

        <section class="featured-recipes">
            <h2>Featured Recipes</h2>
            <div class="recipe-list">
                <div class="recipe-item">
                    <img src="pexels-dana-tentis-118658-691114.jpg" alt="Recipe 1">
                    <h3>Share recipes</h3>
                </div>
                <div class="recipe-item">
                    <img src="pexels-valeriya-1860208.jpg" alt="Recipe 2">
                    <h3>Discover new culture</h3>
                </div>
                <div class="recipe-item">
                    <img src="pexels-sydney-troxell-223521-708488.jpg" alt="Recipe 3">
                    <h3>Save your favorit recipes</h3>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Recipe Sharing Website. All rights reserved.</p>
    </footer>
</body>
</html>
