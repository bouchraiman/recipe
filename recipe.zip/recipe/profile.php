<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Recipe Sharing Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes.php">Recipes</a></li>
                <li><a href="submit.php">Submit Recipe</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="profile">
            <h2>Your Profile</h2>
            <p><strong>Username:</strong> User1</p>
            <p><strong>Email:</strong> user1@example.com</p>

            <h3>Your Submitted Recipes</h3>
            <div class="recipe-list">
                <div class="recipe-item">
                    <img src="recipe1.jpg" alt="Recipe 1">
                    <h3><a href="recipe-detail.html">Recipe Title 1</a></h3>
                </div>
                <div class="recipe-item">
                    <img src="recipe2.jpg" alt="Recipe 2">
                    <h3><a href="recipe-detail.html">Recipe Title 2</a></h3>
                </div>
                <!-- Add more user recipes here -->
            </div>

            <h3>Your Saved Recipes</h3>
            <div class="recipe-list">
                <div class="recipe-item">
                    <img src="recipe3.jpg" alt="Recipe 3">
                    <h3><a href="recipe-detail.html">Recipe Title 3</a></h3>
                </div>
                <div class="recipe-item">
                    <img src="recipe4.jpg" alt="Recipe 4">
                    <h3><a href="recipe-detail.html">Recipe Title 4</a></h3>
                </div>
                <!-- Add more saved recipes here -->
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Recipe Sharing Website. All rights reserved.</p>
    </footer>
</body>
</html>
