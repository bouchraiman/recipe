<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recipes - Recipe Sharing Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes.php">Recipes</a></li>
                <li><a href="submit.php">Submit Recipe</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="recipe-listing">
            <h2>All Recipes</h2>
            <div class="recipe-list">
                <div class="recipe-item">
                    <img src="pexels-jessbaileydesign-917302.jpg" alt="Recipe 1">
                    <h2> Choclate Cupcake </h2>
                    <h3><a href="recipe-detail.html">1 ⅓ cups all-purpose flour <br>¾ cup unsweetened cocoa powder <br>2 teaspoons baking powder<br>¼ teaspoon baking soda<br>
⅛ teaspoon salt<br>

1 ½ cups white sugar<br>3 tlespoons butter, softened<br>2 large eggs<br>
¾ teaspoon vanilla extract<br>1 cup milk</a></h3>
                </div>
                <div class="recipe-item">
                    <img src="pexels-muffin-1653877.jpg" alt="Recipe 2">
                    <h2>PIZZA</h2>
                    <h3><a href="recipe-detail.html">1 cup warm water (110 degrees F/45 degrees C)<br>1 (.25 ounce) package active dry yeast
<br>1 teaspoon white sugar<br>
2 ½ cups bread flour<br>2 tablespoons olive oil<br>1 teaspoon salt</a></h3>
                </div>
                <div class="recipe-item">
                    <img src="pexels-ash-craig-122861-376464.jpg" alt="Recipe 3">
                    <h2>Crepe</h2>
                    <h3><a href="recipe-detail.html">¾ cup all-purpose flour<br>½ cup milk<br>½ cup water<br>3 eggs
<br>3 tablespoons butter, melted<br>½ teaspoon salt
<br>1 ¼ cups sifted confectioners' sugar
<br>1 (8 ounce) package cream cheese, softened<br>1 tablespoon lemon juice<br>1 teaspoon lemon zest<br>½ teaspoon vanilla extract
1 cup heavy cream, whipped<br>
4 cups sliced strawberrie</a></h3>
                </div>
                <!-- Add more recipes here -->
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Recipe Sharing Website. All rights reserved.</p>
    </footer>
</body>
</html>
