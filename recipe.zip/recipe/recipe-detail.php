<?php
include 'db_connect.php';

$recipe_id = $_GET['recipe_id'];

$sql = "SELECT * FROM Recipes WHERE recipe_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $recipe_id);
$stmt->execute();
$recipe = $stmt->get_result()->fetch_assoc();

$sql_comments = "SELECT Comments.comment_text, Users.username FROM Comments JOIN Users ON Comments.user_id = Users.user_id WHERE recipe_id = ?";
$stmt = $conn->prepare($sql_comments);
$stmt->bind_param("i", $recipe_id);
$stmt->execute();
$comments = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recipe Detail - Recipe Sharing Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes.php">Recipes</a></li>
                <li><a href="submit.php">Submit Recipe</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="recipe-detail">
            <h2>Recipe Title</h2>
            <img src="recipe1.jpg" alt="Recipe Image">
            <p>Description of the recipe.</p>

            <h3>Ingredients</h3>
            <ul>
                <li>Ingredient 1</li>
                <li>Ingredient 2</li>
                <li>Ingredient 3</li>
            </ul>

            <h3>Instructions</h3>
            <ol>
                <li>Step 1: Do this.</li>
                <li>Step 2: Do that.</li>
                <li>Step 3: Enjoy your meal!</li>
            </ol>

            <section class="comments">
                <h3>Comments</h3>
                <div class="comment">
                    <p><strong>User1:</strong> Great recipe! My family loved it.</p>
                </div>
                <div class="comment">
                    <p><strong>User2:</strong> Simple and delicious.</p>
                </div>
                <!-- More comments -->
            </section>

            <section class="add-comment">
                <h3>Add a Comment</h3>
                <form action="#" method="post">
                    <textarea name="comment" placeholder="Write your comment here..."></textarea>
                    <button type="submit">Submit Comment</button>
                </form>
            </section>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Recipe Sharing Website. All rights reserved.</p>
    </footer>
</body>
</html>
