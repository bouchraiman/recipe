<?php
// Database connection details
$servername = "localhost";  // Use "localhost" or "127.0.0.1"
$username = "your_username"; // Replace with your MySQL username
$password = "your_password"; // Replace with your MySQL password
$database = "recipe_sharing"; // Replace with your database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $database);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If you want to debug, uncomment the next line
// echo "Connected successfully!";
?>
