<?php
include 'db_connect.php';

if ($conn) {
    echo "Connected successfully!";
} else {
    echo "Connection failed!";
}
?>
