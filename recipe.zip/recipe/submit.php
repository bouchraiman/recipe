<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id']; // Assume user is logged in and user_id is available
    $title = $_POST['title'];
    $description = $_POST['description'];
    $instructions = $_POST['instructions'];
    $image_url = $_POST['image_url']; // Assume this comes from a file upload

    $sql = "INSERT INTO Recipes (user_id, title, description, instructions, image_url) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issss", $user_id, $title, $description, $instructions, $image_url);

    if ($stmt->execute()) {
        echo "Recipe added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Recipe - Recipe Sharing Website</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="recipes.php">Recipes</a></li>
                <li><a href="submit.php">Submit Recipe</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="submit-recipe">
            <h2>Submit Your Recipe</h2>
            <form action="#" method="post">
                <label for="title">Recipe Title</label>
                <input type="text" id="title" name="title" required>

                <label for="description">Description</label>
                <textarea id="description" name="description" required></textarea>

                <label for="ingredients">Ingredients (comma-separated)</label>
                <textarea id="ingredients" name="ingredients" required></textarea>

                <label for="instructions">Instructions</label>
                <textarea id="instructions" name="instructions" required></textarea>

                <label for="image">Image URL</label>
                <input type="url" id="image" name="image" required>

                <button type="submit">Submit Recipe</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 Recipe Sharing Website. All rights reserved.</p>
    </footer>
</body>
</html>
